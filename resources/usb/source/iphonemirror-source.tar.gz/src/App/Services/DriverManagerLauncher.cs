using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using IPhoneMirror.App.Localization;

namespace IPhoneMirror.App.Services;

internal sealed record DriverManagerLaunchResult(
    bool Success,
    string? ExecutablePath,
    string Message,
    int? ProcessId = null);

internal sealed class DriverManagerLauncher
{
    private const string ExecutableName = "iPhoneMirror.Driver.exe";
    private const int SwRestore = 9;

    internal DriverManagerLaunchResult Launch()
    {
        string? executablePath = null;
        try
        {
            executablePath = FindExecutable(
                AppContext.BaseDirectory,
                Environment.GetEnvironmentVariable("IPHONE_MIRROR_DRIVER_MANAGER"),
                Environment.CurrentDirectory);
            if (executablePath is null)
                return new(false, null, LocalizationService.Get("DriverManagerExecutableMissing"));
            if (!string.Equals(Path.GetExtension(executablePath), ".exe",
                    StringComparison.OrdinalIgnoreCase))
                return new(false, executablePath,
                    LocalizationService.Get("DriverManagerPathInvalid"));

            if (TryActivateExisting(executablePath) is { } existingId)
                return new(true, executablePath, LocalizationService.Get("DriverManagerActivated"), existingId);

            DiagnosticLogger.Info("driver", "manager_launch_requested",
                ("file", Path.GetFileName(executablePath)),
                ("use_shell_execute", false));
            var start = new ProcessStartInfo
            {
                FileName = executablePath,
                WorkingDirectory = Path.GetDirectoryName(executablePath)!,
                // This is an application executable, not a document or URI.
                // Avoid ShellExecute so a user file association can never
                // redirect the automatic driver-repair action to another app.
                UseShellExecute = false,
                CreateNoWindow = true,
            };
            start.ArgumentList.Add("--language");
            start.ArgumentList.Add(LocalizationService.EffectiveCulture.Name);
            start.ArgumentList.Add("--theme");
            start.ArgumentList.Add(ThemeService.Preference.ToString());
            using var process = Process.Start(start);
            return process is null
                ? new(false, executablePath, LocalizationService.Get("DriverManagerProcessStartFailed"))
                : new(true, executablePath, LocalizationService.Get("DriverManagerStarted"), process.Id);
        }
        catch (Exception error)
        {
            DiagnosticLogger.Exception("driver", "manager_launch_failed", error,
                ("file", Path.GetFileName(executablePath)));
            return new(false, executablePath, error.Message);
        }
    }

    internal static string? FindExecutable(string baseDirectory,
        string? overridePath = null, string? workingDirectory = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(baseDirectory);
        var basePath = Path.GetFullPath(baseDirectory);
        var workingPath = Path.GetFullPath(workingDirectory ?? Environment.CurrentDirectory);
        var parentPath = Directory.GetParent(basePath)?.FullName;
        var candidates = new List<string?>
        {
            ResolveCandidate(overridePath, workingPath),
            Path.Combine(basePath, ExecutableName),
            Path.Combine(basePath, "Tools", ExecutableName),
            parentPath is null ? null : Path.Combine(parentPath, "iPhoneMirror.Driver", ExecutableName),
            Path.Combine(workingPath, "outputs", "iPhoneMirror.Driver", ExecutableName),
            Path.Combine(workingPath, ExecutableName),
        };

        return candidates
            .Where(path => !string.IsNullOrWhiteSpace(path))
            .Select(path => Path.GetFullPath(path!))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .FirstOrDefault(File.Exists);
    }

    private static string? ResolveCandidate(string? path, string workingDirectory)
    {
        if (string.IsNullOrWhiteSpace(path)) return null;
        return Path.IsPathRooted(path) ? path : Path.Combine(workingDirectory, path);
    }

    internal async Task<DriverManagerLaunchResult> LaunchAndWaitAsync(CancellationToken token)
    {
        token.ThrowIfCancellationRequested();
        var result = Launch();
        if (!result.Success || result.ProcessId is not { } id) return result;
        try
        {
            using var process = Process.GetProcessById(id);
            // Cancelling setup stops waiting, never an independent driver's installation.
            await process.WaitForExitAsync(token);
        }
        catch (ArgumentException) { /* The window already exited. Recheck actual drivers. */ }
        return result;
    }

    private static int? TryActivateExisting(string executablePath)
    {
        foreach (var process in Process.GetProcessesByName(
                     Path.GetFileNameWithoutExtension(ExecutableName)))
        {
            using (process)
            {
                try
                {
                    if (!string.Equals(process.MainModule?.FileName, executablePath,
                            StringComparison.OrdinalIgnoreCase) || process.MainWindowHandle == 0)
                        continue;
                    _ = ShowWindowAsync(process.MainWindowHandle, SwRestore);
                    _ = SetForegroundWindow(process.MainWindowHandle);
                    return process.Id;
                }
                catch (Exception error)
                {
                    // A protected or exiting process is not a usable existing window.
                    DiagnosticLogger.ExceptionOnce("driver-window-enumeration",
                        "driver", "existing_window_probe_failed", error);
                }
            }
        }
        return null;
    }

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool ShowWindowAsync(nint window, int command);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetForegroundWindow(nint window);
}
