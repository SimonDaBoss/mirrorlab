using IPhoneMirror.App.Localization;
using IPhoneMirror.App.Models;
using IPhoneMirror.App.ViewModels;
using IPhoneMirror.App.Windows;
using IPhoneMirror.App.Controls;

namespace IPhoneMirror.App.Services;

/// <summary>Owns one independent native preview window per device UDID.</summary>
internal sealed class MultiDevicePreviewManager : IDisposable
{
    private readonly MainViewModel viewModel;
    private readonly Func<string, nint, bool> _isReverseControlEnabledForWindow;
    private readonly Dictionary<string, NativePreviewWindow> _windows =
        new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, Task<(bool Success, string Message)>> _opening =
        new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, ProtectedContentPresentation> _protectionStates =
        new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<string> _sessionRecoveries =
        new(StringComparer.OrdinalIgnoreCase);
    private bool _disposing;
    private bool _disposed;

    internal event Action<string, nint>? ReverseControlRequested;
    internal event Action<string, nint>? UsbControlRequested;
    internal event Action<string, nint>? WirelessControlRequested;
    internal event Action<string>? PreviewClosed;
    internal event Action<string, PreviewPointerEventArgs>? PointerInput;
    internal event Action<string, PreviewKeyboardEventArgs>? KeyboardInput;
    internal event Action<string, nint, bool>? KeyboardFocusChanged;

    internal MultiDevicePreviewManager(MainViewModel viewModel,
        Func<string, nint, bool>? isReverseControlEnabledForWindow = null)
    {
        this.viewModel = viewModel;
        _isReverseControlEnabledForWindow = isReverseControlEnabledForWindow ??
            ((udid, _) => viewModel.BluetoothControlIsInputEnabled &&
                viewModel.IsBluetoothControlTarget(udid));
        viewModel.DeviceSessionHandleChanged += OnDeviceSessionHandleChanged;
        viewModel.DeviceSessionRecoveryStateChanged += OnDeviceSessionRecoveryStateChanged;
        viewModel.DeviceProtectionStateChanged += OnDeviceProtectionStateChanged;
        LocalizationService.LanguageChanged += OnLanguageChanged;
    }

    internal bool IsOpen(DeviceViewModel? device) => device is not null &&
        _windows.ContainsKey(device.Udid);
    internal bool HasAnyOpen => _windows.Count != 0;

    internal nint GetWindowHandle(string? udid) =>
        !string.IsNullOrWhiteSpace(udid) && _windows.TryGetValue(udid, out var window)
            ? window.Handle : 0;

    internal bool ContainsWindow(nint handle) => handle != 0 && _windows.Values.Any(w => w.Handle == handle);
    internal bool IsFullScreenWindow(nint handle) => _windows.Values.Any(w => w.Handle == handle && w.IsFullScreen);
    internal bool ToggleFullScreenWindow(nint handle)
    {
        var window = _windows.Values.FirstOrDefault(w => w.Handle == handle);
        if (window is null) return false;
        window.ToggleFullScreen();
        return true;
    }

    internal bool Activate(string? udid)
    {
        if (string.IsNullOrWhiteSpace(udid) ||
            !_windows.TryGetValue(udid, out var window)) return false;
        window.Activate();
        return true;
    }

    internal bool PrepareUsbControlWindow(string? udid)
    {
        if (string.IsNullOrWhiteSpace(udid) ||
            !_windows.TryGetValue(udid, out var window)) return false;
        window.PrepareForUsbControl();
        return true;
    }

    internal bool TryGetControlGeometry(string? udid, out uint width,
        out uint height, out int rotation)
    {
        width = height = 0;
        rotation = 0;
        if (string.IsNullOrWhiteSpace(udid) ||
            !_windows.TryGetValue(udid, out var window)) return false;
        (width, height, rotation) = window.ControlGeometry;
        return width != 0 && height != 0;
    }

    internal bool IsFullScreen(string udid) =>
        _windows.TryGetValue(udid, out var window) && window.IsFullScreen;

    internal Task<(bool Success, string Message)> ShowAsync(DeviceViewModel device,
        CancellationToken cancellation = default)
    {
        cancellation.ThrowIfCancellationRequested();
        viewModel.AddDiagnosticLog(AppLog.Event("independent_preview_show_requested",
            ("device", AppLog.Device(device.Udid)),
            ("kind", device.IsWireless ? "wireless" : "wired"),
            ("existing", _windows.ContainsKey(device.Udid)),
            ("disposing", _disposing)));
        if (_disposing)
            return Task.FromResult((false, LocalizationService.Get("CaptureStopped")));
        if (_windows.TryGetValue(device.Udid, out var existing))
        {
            var currentHandle = viewModel.GetDeviceSessionHandle(device.Udid);
            if (currentHandle != 0 && existing.SessionHandle == currentHandle)
            {
                existing.Activate();
                viewModel.AddDiagnosticLog(AppLog.Event("independent_preview_reused",
                    ("device", AppLog.Device(device.Udid)),
                    ("handle", AppLog.Handle(currentHandle))));
                return Task.FromResult((true, string.Empty));
            }
            _windows.Remove(device.Udid);
            existing.Dispose();
        }
        // A joining request may stop waiting, but does not own another
        // caller's window/session creation and must not cancel it.
        if (_opening.TryGetValue(device.Udid, out var pending)) return pending.WaitAsync(cancellation);

        var opening = ShowCoreAsync(device, cancellation);
        _opening[device.Udid] = opening;
        return CompleteOpeningAsync(device.Udid, opening);
    }

    private async Task<(bool Success, string Message)> CompleteOpeningAsync(string udid,
        Task<(bool Success, string Message)> opening)
    {
        try
        {
            return await opening;
        }
        finally
        {
            if (_opening.TryGetValue(udid, out var current) && ReferenceEquals(current, opening))
                _opening.Remove(udid);
        }
    }

    private async Task<(bool Success, string Message)> ShowCoreAsync(DeviceViewModel device,
        CancellationToken cancellation)
    {
        var started = await viewModel.StartBackgroundSessionAsync(device, cancellation);
        if (cancellation.IsCancellationRequested)
        {
            if (started.Created)
                await viewModel.StopDeviceSessionAsync(device.Udid, started.Handle);
            cancellation.ThrowIfCancellationRequested();
        }
        if (!started.Success)
        {
            viewModel.AddDiagnosticLog(AppLog.Event("independent_preview_session_failed",
                ("device", AppLog.Device(device.Udid)),
                ("message", started.Message)));
            return (false, started.Message);
        }
        if (_disposing)
        {
            try
            {
                if (started.Created)
                    await viewModel.StopDeviceSessionAsync(
                        device.Udid, started.Handle, preserveIfSelected: true);
            }
            catch (Exception error)
            {
                viewModel.AddUiLog(LocalizationService.Format(
                    "StopFailedFormat", error.Message));
            }
            return (false, LocalizationService.Get("CaptureStopped"));
        }
        var profile = DeviceCornerProfileResolver.Resolve(device.ProductType, 1206, 2622);
        var cornerRadius = profile.IsRounded ? profile.RadiusRatio : 0;
        _ = Interop.NativeCore.SetDeviceCornerProfile(started.Handle,
            cornerRadius, profile.CurveExponent);
        if (!NativePreviewWindow.TryCreateAndShowForSession(started.Handle, 1206, 2622,
                $"iPhoneMirror — {device.DisplayName}", cornerRadius, profile.CurveExponent,
                () => viewModel.IsDeviceAudioEnabled(device.Udid),
                 () => viewModel.ActiveDeviceSessionCount,
                 enabled => LogAudioResult(viewModel.SetDeviceAudioEnabled(device.Udid, enabled)),
                 () => LogAudioResult(viewModel.MuteOtherDeviceSessions(device.Udid)),
                 ownerHwnd => viewModel.ShowImageSettings(device.Udid, ownerHwnd),
                 () => viewModel.ShowProjectionSettings(device.Udid),
                 out var window, viewModel.AddDiagnosticLog,
                 // A process can have Bluetooth reverse control enabled for a
                 // different preview. Only the active independent control
                 // window may capture input or hide the system cursor.
                 hwnd => _isReverseControlEnabledForWindow(device.Udid, hwnd),
                 args => PointerInput?.Invoke(device.Udid, args),
                 args => KeyboardInput?.Invoke(device.Udid, args),
                 hwnd => ReverseControlRequested?.Invoke(device.Udid, hwnd),
                 () => viewModel.IsUsbControlTarget(device.Udid),
                 hwnd => UsbControlRequested?.Invoke(device.Udid, hwnd),
                 hwnd => WirelessControlRequested?.Invoke(device.Udid, hwnd)) || window is null)
        {
            if (started.Created)
                await viewModel.StopDeviceSessionAsync(
                    device.Udid, started.Handle, preserveIfSelected: true);
            return (false, LocalizationService.Get("PreviewRendererAttachFailed"));
        }
        _windows[device.Udid] = window;
        window.ActivationChanged += active =>
            KeyboardFocusChanged?.Invoke(device.Udid, window.Handle, active);
        KeyboardFocusChanged?.Invoke(device.Udid, window.Handle, true);
        if (_protectionStates.TryGetValue(device.Udid, out var protection))
            window.SetProtectedContent(protection.IsProtected,
                protection.AudioDisplay);
        viewModel.AddDiagnosticLog(AppLog.Event("independent_preview_opened",
            ("device", AppLog.Device(device.Udid)),
            ("handle", AppLog.Handle(started.Handle)),
            ("created_session", started.Created)));
        window.Closed += async (_, _) =>
        {
            if (!_windows.TryGetValue(device.Udid, out var tracked) ||
                !ReferenceEquals(tracked, window)) return;
            _windows.Remove(device.Udid);
            PreviewClosed?.Invoke(device.Udid);
            var closingHandle = window.SessionHandle;
            viewModel.AddDiagnosticLog(AppLog.Event("independent_preview_closed",
                ("device", AppLog.Device(device.Udid)),
                ("handle", AppLog.Handle(closingHandle)),
                ("created_session", started.Created),
                ("disposing", _disposing)));
            if (_disposing || (!started.Created && !viewModel.IsTrayApplicationMode)) return;
            try
            {
                // The selected-main check is performed under the same core
                // gate that revokes the handle, closing the selection race.
                await viewModel.StopDeviceSessionAsync(
                    device.Udid, closingHandle, preserveIfSelected: true,
                    pauseWireless: viewModel.IsTrayApplicationMode);
            }
            catch (Exception error)
            {
                viewModel.AddUiLog(LocalizationService.Format(
                    "StopFailedFormat", error.Message));
            }
        };
        return (true, string.Empty);
    }

    private void LogAudioResult((bool Success, string Message) result)
    {
        if (!string.IsNullOrWhiteSpace(result.Message)) viewModel.AddUiLog(result.Message);
    }

    private void OnDeviceSessionHandleChanged(string udid, ulong handle)
    {
        _protectionStates.Remove(udid);
        if (!_windows.TryGetValue(udid, out var window))
            return;

        if (handle == 0 && _sessionRecoveries.Contains(udid))
        {
            viewModel.AddDiagnosticLog(AppLog.Event(
                "independent_preview_recovery_pending",
                ("device", AppLog.Device(udid)),
                ("old_handle", AppLog.Handle(window.SessionHandle))));
            return;
        }

        if (handle != 0 && _sessionRecoveries.Contains(udid) &&
            window.RebindSession(handle))
        {
            return;
        }
        if (window.SessionHandle == handle) return;

        _windows.Remove(udid);
        PreviewClosed?.Invoke(udid);
        viewModel.AddDiagnosticLog(AppLog.Event("independent_preview_handle_invalidated",
            ("device", AppLog.Device(udid)),
            ("old_handle", AppLog.Handle(window.SessionHandle)),
            ("new_handle", AppLog.Handle(handle))));
        try { window.Dispose(); }
        catch (Exception error)
        {
            try
            {
                viewModel.AddUiLog(LocalizationService.Format(
                    "StopFailedFormat", error.Message));
            }
            catch (Exception uiError)
            {
                DiagnosticLogger.Exception("window", "preview_dispose_ui_failed",
                    uiError, ("device", AppLog.Device(udid)));
            }
        }
    }

    private void OnDeviceSessionRecoveryStateChanged(string udid, bool recovering)
    {
        if (recovering)
        {
            _sessionRecoveries.Add(udid);
            return;
        }

        _sessionRecoveries.Remove(udid);
        if (viewModel.GetDeviceSessionHandle(udid) != 0 ||
            !_windows.TryGetValue(udid, out var window)) return;

        _windows.Remove(udid);
        PreviewClosed?.Invoke(udid);
        viewModel.AddDiagnosticLog(AppLog.Event(
            "independent_preview_recovery_failed",
            ("device", AppLog.Device(udid)),
            ("old_handle", AppLog.Handle(window.SessionHandle))));
        try { window.Dispose(); }
        catch (Exception error)
        {
            viewModel.AddDiagnosticLog(AppLog.Event(
                "independent_preview_dispose_failed",
                ("handle", AppLog.Handle(window.SessionHandle)),
                ("error", AppLog.Error(error))));
        }
    }

    private void OnDeviceProtectionStateChanged(string udid,
        ProtectedContentPresentation presentation)
    {
        if (presentation.IsProtected) _protectionStates[udid] = presentation;
        else _protectionStates.Remove(udid);
        try
        {
            if (_windows.TryGetValue(udid, out var window))
                window.SetProtectedContent(presentation.IsProtected,
                    presentation.AudioDisplay);
        }
        catch (Exception error)
        {
            viewModel.AddDiagnosticLog(AppLog.Event(
                "independent_preview_protection_failed",
                ("device", AppLog.Device(udid)),
                ("protected", presentation.IsProtected),
                ("error", AppLog.Error(error))));
        }
    }

    private void OnLanguageChanged(object? sender, EventArgs e)
    {
        foreach (var (udid, presentation) in _protectionStates.ToArray())
            try
            {
                if (_windows.TryGetValue(udid, out var window))
                    window.SetProtectedContent(true, presentation.AudioDisplay);
            }
            catch (Exception error)
            {
                viewModel.AddDiagnosticLog(AppLog.Event(
                    "independent_preview_protection_language_failed",
                    ("device", AppLog.Device(udid)),
                    ("error", AppLog.Error(error))));
            }
    }

    internal void UpdateDevice(string udid, uint width, uint height)
    {
        if (_windows.TryGetValue(udid, out var window) && width != 0 && height != 0)
            window.SetSourceDimensions(width, height);
    }

    internal bool Refresh(DeviceViewModel? device) => device is not null &&
        _windows.TryGetValue(device.Udid, out var window) && window.RefreshPreview();

    internal async Task<bool> ToggleFullScreenAsync(DeviceViewModel device)
    {
        var result = await ShowAsync(device);
        if (!result.Success || !_windows.TryGetValue(device.Udid, out var window)) return false;
        window.ToggleFullScreen();
        return true;
    }

    internal void UpdateDevice(DeviceViewModel? device, uint width, uint height)
    {
        if (device is null) return;
        UpdateDevice(device.Udid, width, height);
        // Do not re-apply the model default here. The detached window owns
        // the user's per-window corner override (including "remove corners");
        // applying the profile on every size/status notification would undo
        // that menu choice as soon as the window is focused or resized.
    }

    internal void HideForShutdown()
    {
        if (_disposed) return;
        _disposing = true;
        foreach (var window in _windows.Values.ToArray())
        {
            try { window.HideForShutdown(); }
            catch (Exception error)
            {
                viewModel.AddDiagnosticLog(AppLog.Event(
                    "independent_preview_hide_failed",
                    ("handle", AppLog.Handle(window.SessionHandle)),
                    ("error", AppLog.Error(error))));
            }
        }
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _disposing = true;
        viewModel.AddDiagnosticLog(AppLog.Event("independent_preview_manager_dispose",
            ("count", _windows.Count)));
        viewModel.DeviceSessionHandleChanged -= OnDeviceSessionHandleChanged;
        viewModel.DeviceSessionRecoveryStateChanged -= OnDeviceSessionRecoveryStateChanged;
        viewModel.DeviceProtectionStateChanged -= OnDeviceProtectionStateChanged;
        LocalizationService.LanguageChanged -= OnLanguageChanged;
        foreach (var window in _windows.Values.ToArray())
        {
            try { window.Dispose(); }
            catch (Exception error)
            {
                viewModel.AddDiagnosticLog(AppLog.Event(
                    "independent_preview_dispose_failed",
                    ("handle", AppLog.Handle(window.SessionHandle)),
                    ("error", AppLog.Error(error))));
            }
        }
        _windows.Clear();
        _sessionRecoveries.Clear();
        _protectionStates.Clear();
    }
}
